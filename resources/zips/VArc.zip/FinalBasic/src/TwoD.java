import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

public class TwoD extends JPanel{

	JButton but = new JButton("AAA");
	Lesson lsn = null;
	
	TwoD(Lesson lsn)
	{
		this.lsn = lsn;
		JPanel mainPanel = new JPanel();
		mainPanel.setMinimumSize((new Dimension(500,500)));
		mainPanel.add(but);
		but.addActionListener(new buttonListener());
		add(mainPanel);
	}
	
	private class buttonListener implements ActionListener
	{

		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			lsn.getCanvas().invertDir();
		}
		
	}
	
}
