/**
 * Lesson6.java
 *
 * Author: Jeff Kirby (report from Darren Hodges java port ) 
 * Date: 22/12/2001
 *
 * Port of the NeHe OpenGL Tutorial (Lesson 6: Texture Mapping)
 * to Java using the GL4Java interface to OpenGL.
 * 
 *
 */

   import java.applet.Applet;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Rectangle;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;


   public class Lesson extends Applet
   {
      /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//Our rendering canvas ( Customized GLAnimeCanvas, which can animate itself )
   
      NeHeCanvas canvas = null;
      PlanPane pp = null;
      static boolean appletMode=false;
      ArrayList wallList = new ArrayList();
      
   /** void init()  Initialise the applet.  */
      public void init()
      {
         setLayout(new FlowLayout()); // Border layout so that component will use all space
         pp = new PlanPane(this);
         canvas = new NeHeCanvas(500, 500,wallList); //Create our canvas and add it to the center of the applet
         canvas.requestFocus();        // attempt to get focus to the canvase asap ( don't work to well )
         add(pp);
         add(canvas);        // add the canvas to the applet
         setSize(1000, 500);
         //wallList.add(new Rectangle(10,10,20,20));
        // wallList.add(new Rectangle(-10,-10,20,20));
      }
   
   /** void start() Start the applet. */
      public void start()
      { 
         canvas.start(); /*Start animating the canvas */ 
         if(!appletMode)
            canvas.codeBase = getCodeBase();
      }
   
   
   /** void stop() Stop the applet. */
      public void stop()
      {
         canvas.stop();//Stop animating the canvas
      }
   
   
    /** void destroy() Destroy the applet. */
      public void destroy()
      {
         canvas.stop();  //Stop animating the canvas
         canvas.cvsDispose();  //Destroy the canvas
      }
   
      public NeHeCanvas getCanvas()
      {
    	  return canvas;
      }

      public PlanPane getPlanPane()
      {
    	  return pp;
      }
      
      public ArrayList getWallList()
      {
    	  return wallList;
      }

      // Main method (This is what gets run when you run as an application) 
      public static void main( String args[] ) {
         appletMode=true;	
         Lesson applet = new Lesson();
         applet.setSize(640,480);
         applet.init();
         applet.start();
      
         Frame f = new Frame("NeHe Lesson 6 - Texture Mapping");
         f.add(applet);
         f.pack();// make the frame the size of the Applet
         f.setVisible(true);
      
         //GLContext.gljNativeDebug = true; // if you want lots of messages, or want to know what went wrong :)
         //GLContext.gljThreadDebug = false;
         //GLContext.gljClassDebug = true;
      
      
         f.addWindowListener( // Enable the close button just to be nice
                               new WindowAdapter()
                               {
                                  public void windowClosed(WindowEvent e)
                                  {
                                     System.exit(0);
                                  }
                                  public void windowClosing(WindowEvent e)
                                  {
                                     windowClosed(e);
                                  }
                               }
                            );
      
      }
   
   
   }
