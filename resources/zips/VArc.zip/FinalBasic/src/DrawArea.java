import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.JPanel;


public class DrawArea extends JPanel{

	int x1,y1,x2,y2,oldx,oldy;
	int wallThickness = 10;
	Graphics G;
	DrawArea(JPanel p,Lesson lsn)
	{
		setVisible(true);
		setPreferredSize(new Dimension(400,500));
		clickListener cl = new clickListener(p,lsn);
		this.addMouseListener(cl);
		this.addMouseMotionListener(cl);
	}


	private class clickListener implements MouseListener, MouseMotionListener
	{
		JPanel pane;
		Lesson lsn;
		boolean initialLine = true;
		public clickListener(JPanel pane,Lesson lsn) {
			// TODO Auto-generated constructor stub
			this.pane = pane;
			this.lsn = lsn;
		}
		
		public void mouseClicked(MouseEvent e) {
			// TODO Auto-generated method stub
		}
	
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
	
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
	
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			x1=e.getX();
			y1=e.getY();
		}
	
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			x2=e.getX();
			y2=e.getY();
			G=pane.getGraphics();
	       for(int i=0;i<4;i++)
	       {
	    	   Rectangle[] rect = new Rectangle[4];
	    	   rect[i] = drawWall(G,x1,y1,x2,y2,wallThickness)[i];
	    	   G.drawLine(rect[i].x,rect[i].y,rect[i].x+rect[i].width,rect[i].y+rect[i].height);
	    	   lsn.getWallList().add(rect[i]);
	       }
			System.out.println((x1-200)+" "+(x2-200)+" "+(y1-250)+" "+(y2-250));
			initialLine=true;
		}
	
		public void mouseDragged(MouseEvent e) {
			// TODO Auto-generated method stub
			lineOperation(e);
		}
	
		public void mouseMoved(MouseEvent e) {
			// TODO Auto-generated method stub
		}

		 public void lineOperation(MouseEvent e)
		 {

		    Graphics g  = pane.getGraphics();
		    g.setColor(Color.BLACK);

		    /*
		      In initial state setup default values
		      for mouse coordinates
		    */
		    if (initialLine)
		    {
		       g.setXORMode(pane.getBackground());
		       for(int i=0;i<4;i++)
		       {
		    	   Rectangle[] rect = new Rectangle[4];
		    	   rect[i] = drawWall(g,x1,y1,x2,y2,wallThickness)[i];
		    	   g.drawLine(rect[i].x,rect[i].y,rect[i].x+rect[i].width,rect[i].y+rect[i].height);
		       }
		       initialLine=false;
		    }

		    /*
		      Make sure that the mouse has actually
		      moved from its previous position.
		    */
		    if (mouseHasMoved(e))
		    {
		       /*
		         Delete previous line shadow
		         by xor-ing the graphical object
		       */
		       g.setXORMode(pane.getBackground());
		       for(int i=0;i<4;i++)
		       {
		    	   Rectangle[] rect = new Rectangle[4];
		    	   rect[i] = drawWall(g,x1,y1,x2,y2,wallThickness)[i];
		    	   g.drawLine(rect[i].x,rect[i].y,rect[i].x+rect[i].width,rect[i].y+rect[i].height);
		       }

		       /* Update new mouse coordinates */
		       x2 = e.getX();
		       y2 = e.getY();

		       /* Draw line shadow */
		       for(int i=0;i<4;i++)
		       {
		    	   Rectangle[] rect = new Rectangle[4];
		    	   rect[i] = drawWall(g,x1,y1,x2,y2,wallThickness)[i];
		    	   g.drawLine(rect[i].x,rect[i].y,rect[i].x+rect[i].width,rect[i].y+rect[i].height);
		       }
		    }

		 }
		
		public Rectangle[] drawWall(Graphics g, int x1, int y1, int x2, int y2,
				float wt) {
			Rectangle[] rect = new Rectangle[4];
			double theta = Math.atan((double)(y2-y1)/(double)(x2-x1));
			rect[0]=new Rectangle(x1+(int)(wt/2.0f*Math.sin(theta)),y1+(int)((wt/2.0f)*Math.cos(theta)),(int)((float)(x2-x1)),(int)((float)(y2-y1)));
			rect[1]=new Rectangle(x2-(int)(wt/2.0f*Math.sin(theta)),y2+(int)((wt/2.0f)*Math.cos(theta)),1*(int)((float)(wt)*Math.sin(theta)),-1*(int)((float)(wt)*Math.cos(theta)));
			rect[2]=new Rectangle(x1-(int)(wt/2.0f*Math.sin(theta)),y1-(int)((wt/2.0f)*Math.cos(theta)),(int)((float)(x2-x1)),(int)((float)(y2-y1)));
			rect[3]=new Rectangle(x1-(int)(wt/2.0f*Math.sin(theta)),y1+(int)((wt/2.0f)*Math.cos(theta)),1*(int)((float)(wt)*Math.sin(theta)),-1*(int)((float)(wt)*Math.cos(theta)));
			//System.out.println("GG "+180.0f*theta/3.14159f+" "+x1+" " + (int)((wt/2.0f)*Math.sin(theta)));
			
			return rect;
		}

		public boolean mouseHasMoved(MouseEvent e)
		 {
		    return (x2 != e.getX() || y2 != e.getY());
		 }
		
	}
}
