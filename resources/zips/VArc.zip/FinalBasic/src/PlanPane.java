import java.awt.BorderLayout;

import javax.swing.JPanel;


public class PlanPane extends JPanel{
	
	private Lesson lsn;
	PlanPane(Lesson lsn)
	{
		this.lsn = lsn;
		setLayout(new BorderLayout());
		//ToolBar toolBar = new ToolBar();
		DrawArea drawArea = new DrawArea(this,lsn);
		//add(toolBar,BorderLayout.WEST);
		add(drawArea,BorderLayout.CENTER);
		setVisible(true);
	}
	
	public Lesson getLesson(){
		return lsn;
	}
}
