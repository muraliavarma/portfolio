package com.murlax.processing.artery;

import java.util.ArrayList;

public class Artery extends Shape {

	Polygon newPolygon;
	ArrayList<CrossSection> crossSectionList;
	ArrayList<CrossSection> originalCrossSectionList;
	private float globalRotationX = 0;
	private float globalTranslation = 0;
	private float globalRotationY = 0;
	//Editing related variables
	private int pickedPointIndex = -1;
	private int pickedCrossSectionIndex = -1;
	private int pickedPolygon = -1;	//0 = inner and 1 = outer
	
	private int smoothingCnt = 0;
	
	public float getGlobalRotationX() {
		return globalRotationX;
	}


	public ArrayList<CrossSection> getCrossSectionList() {
		return crossSectionList;
	}


	public void setGlobalRotationX(float globalRotationX) {
		this.globalRotationX = globalRotationX;
	}


	public float getGlobalTranslation() {
		return globalTranslation;
	}


	public void setGlobalTranslation(float globalTranslation) {
		this.globalTranslation = globalTranslation;
	}


	public float getGlobalRotationY() {
		return globalRotationY;
	}


	public void setGlobalRotationY(float globalRotationY) {
		this.globalRotationY = globalRotationY;
	}


	Artery(MainArtery p, CrossSection crossSection)
	{
		super(p);
		crossSectionList = new ArrayList<CrossSection>();
		crossSectionList.add(crossSection);
		originalCrossSectionList = new ArrayList<CrossSection>();
		originalCrossSectionList.add(crossSection);

		//		newPolygon = new Polygon(p);
		//		newPolygon.setClosed(true);
		//		
		//		this.basePolygon = basePolygon;
		//		this.basePolygon.pointList = basePolygon.pointList;
		//		
		//		for (int i = 0; i < basePolygon.pointList.size(); i++) {
		//			
		//			newPolygon.pointList.add(basePolygon.pointList.get(i));
		//			newPolygon.pointList.get(i).setZ(newPolygon.pointList.get(i).getZ()+Constants.ARTERY_OFFSET_DISTANCE);
		//			
		//		}

	}



	public void addCrossSection(Point point){
		Polygon newBasePolygon = new Polygon(parent);
		Polygon tempBasePolygon = crossSectionList.get(0).getBasePolygon();
		Polygon newOuterPolygon = new Polygon(parent);
		Polygon tempOuterPolygon = crossSectionList.get(0).getOuterPolygon();
		Polygon newInnerPolygon = new Polygon(parent);
		Polygon tempInnerPolygon = crossSectionList.get(0).getInnerPolygon();
		Point fixedCenterOfArea = tempBasePolygon.getCenterOfArea();
		//Point currCenterOfArea = crossSectionList.get(crossSectionList.size()-1).getBasePolygon().getCenterOfArea();
		//currCenterOfArea.setZ(0);
		Vector angleVector = new Vector(fixedCenterOfArea,point);
		globalTranslation += Constants.ARTERY_OFFSET_DISTANCE*Math.sqrt(angleVector.getLength());
		float angleX = angleVector.getY()*(Constants.MAX_ROTATE_ANGLE/Constants.LENGTH_ANGLE_COREL);
		angleX = angleX>Constants.MAX_ROTATE_ANGLE?Constants.MAX_ROTATE_ANGLE:angleX;
		angleX = angleX<-Constants.MAX_ROTATE_ANGLE?-Constants.MAX_ROTATE_ANGLE:angleX;
		float angleY = -angleVector.getX()*(Constants.MAX_ROTATE_ANGLE/Constants.LENGTH_ANGLE_COREL);
		angleY = angleY>Constants.MAX_ROTATE_ANGLE?Constants.MAX_ROTATE_ANGLE:angleY;
		angleY = angleY<-Constants.MAX_ROTATE_ANGLE?-Constants.MAX_ROTATE_ANGLE:angleY;
		parent.pushMatrix();
		globalRotationX += angleX;
		globalRotationY += angleY;
		parent.translate(fixedCenterOfArea.getX(), fixedCenterOfArea.getY(), fixedCenterOfArea.getZ());
		parent.rotateX(globalRotationX);
		parent.rotateY(globalRotationY);
		parent.translate(0, 0, -globalTranslation);

		for (int i = 0; i < crossSectionList.get(crossSectionList.size()-1).getBasePolygon().pointList.size(); i++) {
			newBasePolygon.addPoint(new Point());
			newBasePolygon.pointList.get(i).setX(parent.modelX(tempBasePolygon.pointList.get(i).getX()-fixedCenterOfArea.getX(), tempBasePolygon.pointList.get(i).getY()-fixedCenterOfArea.getY(), tempBasePolygon.pointList.get(i).getZ()-fixedCenterOfArea.getZ()));
			newBasePolygon.pointList.get(i).setY(parent.modelY(tempBasePolygon.pointList.get(i).getX()-fixedCenterOfArea.getX(), tempBasePolygon.pointList.get(i).getY()-fixedCenterOfArea.getY(), tempBasePolygon.pointList.get(i).getZ()-fixedCenterOfArea.getZ()));
			newBasePolygon.pointList.get(i).setZ(parent.modelZ(tempBasePolygon.pointList.get(i).getX()-fixedCenterOfArea.getX(), tempBasePolygon.pointList.get(i).getY()-fixedCenterOfArea.getY(), tempBasePolygon.pointList.get(i).getZ()-fixedCenterOfArea.getZ()));

			newOuterPolygon.addPoint(new Point());
			newOuterPolygon.pointList.get(i).setX(parent.modelX(tempOuterPolygon.pointList.get(i).getX()-fixedCenterOfArea.getX(), tempOuterPolygon.pointList.get(i).getY()-fixedCenterOfArea.getY(), tempOuterPolygon.pointList.get(i).getZ()-fixedCenterOfArea.getZ()));
			newOuterPolygon.pointList.get(i).setY(parent.modelY(tempOuterPolygon.pointList.get(i).getX()-fixedCenterOfArea.getX(), tempOuterPolygon.pointList.get(i).getY()-fixedCenterOfArea.getY(), tempOuterPolygon.pointList.get(i).getZ()-fixedCenterOfArea.getZ()));
			newOuterPolygon.pointList.get(i).setZ(parent.modelZ(tempOuterPolygon.pointList.get(i).getX()-fixedCenterOfArea.getX(), tempOuterPolygon.pointList.get(i).getY()-fixedCenterOfArea.getY(), tempOuterPolygon.pointList.get(i).getZ()-fixedCenterOfArea.getZ()));

			newInnerPolygon.addPoint(new Point());
			newInnerPolygon.pointList.get(i).setX(parent.modelX(tempInnerPolygon.pointList.get(i).getX()-fixedCenterOfArea.getX(), tempInnerPolygon.pointList.get(i).getY()-fixedCenterOfArea.getY(), tempInnerPolygon.pointList.get(i).getZ()-fixedCenterOfArea.getZ()));
			newInnerPolygon.pointList.get(i).setY(parent.modelY(tempInnerPolygon.pointList.get(i).getX()-fixedCenterOfArea.getX(), tempInnerPolygon.pointList.get(i).getY()-fixedCenterOfArea.getY(), tempInnerPolygon.pointList.get(i).getZ()-fixedCenterOfArea.getZ()));
			newInnerPolygon.pointList.get(i).setZ(parent.modelZ(tempInnerPolygon.pointList.get(i).getX()-fixedCenterOfArea.getX(), tempInnerPolygon.pointList.get(i).getY()-fixedCenterOfArea.getY(), tempInnerPolygon.pointList.get(i).getZ()-fixedCenterOfArea.getZ()));
		}
		parent.popMatrix();
		newBasePolygon.setCenterOfArea();
		CrossSection newCrossSection = new CrossSection(parent, newBasePolygon, newInnerPolygon, newOuterPolygon);
		crossSectionList.add(newCrossSection);
		originalCrossSectionList.add(newCrossSection);
		smoothingCnt = 0;
		if(Util.AUTO_SMOOTH_MODE)
			for(int i = 0; i < 3; i++)
				smoothen();
		else 
			crossSectionList = originalCrossSectionList;
	}

	@Override
	public void draw() {
		for (int i = 0; i < crossSectionList.size(); i++) {
			//drawCurves(i);
			crossSectionList.get(i).draw();
			if(i == 0 || i == crossSectionList.size()-1)
				crossSectionList.get(i).drawMesh();
		}
		parent.stroke(255);
		drawcenterSpine();
		parent.noStroke();
		drawWalls();
	}


	private void drawcenterSpine() {
		for(int i = 0; i < crossSectionList.size()-1; i++){
			Point currCenterOfArea = crossSectionList.get(i).getBasePolygon().getCenterOfArea();
			Point nextCenterOfArea = crossSectionList.get(i+1).getBasePolygon().getCenterOfArea();
			parent.line(currCenterOfArea.getX(),currCenterOfArea.getY(),currCenterOfArea.getZ(), nextCenterOfArea.getX(),nextCenterOfArea.getY(),nextCenterOfArea.getZ());
		}
	}


	private void drawWalls() {
		for (int i = 0; i < crossSectionList.size()-1; i++) {
			int currentCrossSectionBasePolygonSize = crossSectionList.get(i).getBasePolygon().pointList.size();
			for (int j = 0; j < currentCrossSectionBasePolygonSize; j++) {
				if(parent.mode == Constants.ARTERY_EDIT_MODE){
					parent.stroke(0,0,200);
					parent.line(crossSectionList.get(i).getInnerPolygon().pointList.get(j).getX(),
							crossSectionList.get(i).getInnerPolygon().pointList.get(j).getY(),
							crossSectionList.get(i).getInnerPolygon().pointList.get(j).getZ(),
							crossSectionList.get(i+1).getInnerPolygon().pointList.get(j).getX(),
							crossSectionList.get(i+1).getInnerPolygon().pointList.get(j).getY(),
							crossSectionList.get(i+1).getInnerPolygon().pointList.get(j).getZ()
							);
					
					parent.line(crossSectionList.get(i).getInnerPolygon().pointList.get(j).getX(),
							crossSectionList.get(i).getInnerPolygon().pointList.get(j).getY(),
							crossSectionList.get(i).getInnerPolygon().pointList.get(j).getZ(),
							crossSectionList.get(i+1).getInnerPolygon().pointList.get((j+1)%currentCrossSectionBasePolygonSize).getX(),
							crossSectionList.get(i+1).getInnerPolygon().pointList.get((j+1)%currentCrossSectionBasePolygonSize).getY(),
							crossSectionList.get(i+1).getInnerPolygon().pointList.get((j+1)%currentCrossSectionBasePolygonSize).getZ()
							);
	
					parent.stroke(200,0,0);
					parent.line(crossSectionList.get(i).getOuterPolygon().pointList.get(j).getX(),
							crossSectionList.get(i).getOuterPolygon().pointList.get(j).getY(),
							crossSectionList.get(i).getOuterPolygon().pointList.get(j).getZ(),
							crossSectionList.get(i+1).getOuterPolygon().pointList.get(j).getX(),
							crossSectionList.get(i+1).getOuterPolygon().pointList.get(j).getY(),
							crossSectionList.get(i+1).getOuterPolygon().pointList.get(j).getZ()
							);
					
					parent.line(crossSectionList.get(i).getOuterPolygon().pointList.get(j).getX(),
							crossSectionList.get(i).getOuterPolygon().pointList.get(j).getY(),
							crossSectionList.get(i).getOuterPolygon().pointList.get(j).getZ(),
							crossSectionList.get(i+1).getOuterPolygon().pointList.get((j+1)%currentCrossSectionBasePolygonSize).getX(),
							crossSectionList.get(i+1).getOuterPolygon().pointList.get((j+1)%currentCrossSectionBasePolygonSize).getY(),
							crossSectionList.get(i+1).getOuterPolygon().pointList.get((j+1)%currentCrossSectionBasePolygonSize).getZ()
							);
				}
				else{
					//inner fillesh!!
					parent.fill(0,0,255);
					//parent.noFill();
					//parent.stroke(0,0,255);
					parent.beginShape();
					parent.vertex(crossSectionList.get(i).getInnerPolygon().pointList.get(j).getX(),
							crossSectionList.get(i).getInnerPolygon().pointList.get(j).getY(),
							crossSectionList.get(i).getInnerPolygon().pointList.get(j).getZ());
					parent.vertex(crossSectionList.get(i+1).getInnerPolygon().pointList.get(j).getX(),
							crossSectionList.get(i+1).getInnerPolygon().pointList.get(j).getY(),
							crossSectionList.get(i+1).getInnerPolygon().pointList.get(j).getZ());
					parent.vertex(crossSectionList.get(i).getInnerPolygon().pointList.get((j+1)%currentCrossSectionBasePolygonSize).getX(),
							crossSectionList.get(i).getInnerPolygon().pointList.get((j+1)%currentCrossSectionBasePolygonSize).getY(),
							crossSectionList.get(i).getInnerPolygon().pointList.get((j+1)%currentCrossSectionBasePolygonSize).getZ());
					parent.endShape();
					//parent.fill(0,255,0);
					parent.beginShape();
					parent.vertex(crossSectionList.get(i+1).getInnerPolygon().pointList.get(j).getX(),
							crossSectionList.get(i+1).getInnerPolygon().pointList.get(j).getY(),
							crossSectionList.get(i+1).getInnerPolygon().pointList.get(j).getZ());
					parent.vertex(crossSectionList.get(i+1).getInnerPolygon().pointList.get((j+1)%currentCrossSectionBasePolygonSize).getX(),
							crossSectionList.get(i+1).getInnerPolygon().pointList.get((j+1)%currentCrossSectionBasePolygonSize).getY(),
							crossSectionList.get(i+1).getInnerPolygon().pointList.get((j+1)%currentCrossSectionBasePolygonSize).getZ());
					parent.vertex(crossSectionList.get(i).getInnerPolygon().pointList.get((j+1)%currentCrossSectionBasePolygonSize).getX(),
							crossSectionList.get(i).getInnerPolygon().pointList.get((j+1)%currentCrossSectionBasePolygonSize).getY(),
							crossSectionList.get(i).getInnerPolygon().pointList.get((j+1)%currentCrossSectionBasePolygonSize).getZ());
					parent.endShape();
	
					//outer fillesh!!
					parent.fill(255,0,0);
					//parent.stroke(255,0,0);
					parent.beginShape();
					parent.vertex(crossSectionList.get(i).getOuterPolygon().pointList.get(j).getX(),
							crossSectionList.get(i).getOuterPolygon().pointList.get(j).getY(),
							crossSectionList.get(i).getOuterPolygon().pointList.get(j).getZ());
					parent.vertex(crossSectionList.get(i+1).getOuterPolygon().pointList.get(j).getX(),
							crossSectionList.get(i+1).getOuterPolygon().pointList.get(j).getY(),
							crossSectionList.get(i+1).getOuterPolygon().pointList.get(j).getZ());
					parent.vertex(crossSectionList.get(i).getOuterPolygon().pointList.get((j+1)%currentCrossSectionBasePolygonSize).getX(),
							crossSectionList.get(i).getOuterPolygon().pointList.get((j+1)%currentCrossSectionBasePolygonSize).getY(),
							crossSectionList.get(i).getOuterPolygon().pointList.get((j+1)%currentCrossSectionBasePolygonSize).getZ());
					parent.endShape();
					parent.beginShape();
					parent.vertex(crossSectionList.get(i+1).getOuterPolygon().pointList.get(j).getX(),
							crossSectionList.get(i+1).getOuterPolygon().pointList.get(j).getY(),
							crossSectionList.get(i+1).getOuterPolygon().pointList.get(j).getZ());
					parent.vertex(crossSectionList.get(i+1).getOuterPolygon().pointList.get((j+1)%currentCrossSectionBasePolygonSize).getX(),
							crossSectionList.get(i+1).getOuterPolygon().pointList.get((j+1)%currentCrossSectionBasePolygonSize).getY(),
							crossSectionList.get(i+1).getOuterPolygon().pointList.get((j+1)%currentCrossSectionBasePolygonSize).getZ());
					parent.vertex(crossSectionList.get(i).getOuterPolygon().pointList.get((j+1)%currentCrossSectionBasePolygonSize).getX(),
							crossSectionList.get(i).getOuterPolygon().pointList.get((j+1)%currentCrossSectionBasePolygonSize).getY(),
							crossSectionList.get(i).getOuterPolygon().pointList.get((j+1)%currentCrossSectionBasePolygonSize).getZ());
					parent.endShape();
				}
			}
		}

	}


	public void smoothen() {
		refine();
		dual();
		dual();
		smoothingCnt++;
	}
	
	private void refine(){
		ArrayList<CrossSection> tempList;
		if(smoothingCnt == 0)
			tempList = originalCrossSectionList;
		else
			tempList = crossSectionList;
		ArrayList<CrossSection> newCrossSectionList = new ArrayList<CrossSection>();
		for (int i = 0; i < tempList.size()-1; i++) {
			newCrossSectionList.add(tempList.get(i));
			//now add average of i and (i+1)th cross sections
			Polygon newBasePolygon = new Polygon(parent);
			Polygon newOuterPolygon = new Polygon(parent);
			Polygon newInnerPolygon = new Polygon(parent);
			for (int j = 0; j < tempList.get(i).getBasePolygon().pointList.size(); j++) {
				newBasePolygon.addPoint(new Point());
				newBasePolygon.pointList.get(j).setPoint(Util.average(tempList.get(i).getBasePolygon().pointList.get(j),tempList.get(i+1).getBasePolygon().pointList.get(j)));
				newInnerPolygon.addPoint(new Point());
				newInnerPolygon.pointList.get(j).setPoint(Util.average(tempList.get(i).getInnerPolygon().pointList.get(j),tempList.get(i+1).getInnerPolygon().pointList.get(j)));
				newOuterPolygon.addPoint(new Point());
				newOuterPolygon.pointList.get(j).setPoint(Util.average(tempList.get(i).getOuterPolygon().pointList.get(j),tempList.get(i+1).getOuterPolygon().pointList.get(j)));
			}
			newBasePolygon.setCenterOfArea();
			CrossSection newCrossSection = new CrossSection(parent, newBasePolygon, newInnerPolygon, newOuterPolygon);
			newCrossSectionList.add(newCrossSection);
		}
		newCrossSectionList.add(tempList.get(tempList.size()-1));
		crossSectionList = newCrossSectionList;
	}
	
	private void dual(){
		
		CrossSection temp = crossSectionList.get(0);
		
		for (int i = 0; i < crossSectionList.size()-1; i++) {
			//now add average of i and (i+1)th cross sections
			Polygon newBasePolygon = new Polygon(parent);
			Polygon newOuterPolygon = new Polygon(parent);
			Polygon newInnerPolygon = new Polygon(parent);
			for (int j = 0; j < crossSectionList.get(i).getBasePolygon().pointList.size(); j++) {
				newBasePolygon.addPoint(new Point());
				newBasePolygon.pointList.get(j).setPoint(Util.average(crossSectionList.get(i).getBasePolygon().pointList.get(j),crossSectionList.get(i+1).getBasePolygon().pointList.get(j)));
				newInnerPolygon.addPoint(new Point());
				newInnerPolygon.pointList.get(j).setPoint(Util.average(crossSectionList.get(i).getInnerPolygon().pointList.get(j),crossSectionList.get(i+1).getInnerPolygon().pointList.get(j)));
				newOuterPolygon.addPoint(new Point());
				newOuterPolygon.pointList.get(j).setPoint(Util.average(crossSectionList.get(i).getOuterPolygon().pointList.get(j),crossSectionList.get(i+1).getOuterPolygon().pointList.get(j)));
			}
			newBasePolygon.setCenterOfArea();
			CrossSection newCrossSection = new CrossSection(parent, newBasePolygon, newInnerPolygon, newOuterPolygon);
			
			crossSectionList.set(i, newCrossSection);
		}
		crossSectionList.add(0,temp);
	}


	public void unSmoothen() {
		crossSectionList = originalCrossSectionList;
	}


	public void pickClosestPoint(int mouseX, int mouseY, int z) {
		for (int i = 0; i < crossSectionList.size(); i++) {
			CrossSection currentCrossSection = crossSectionList.get(i);
			int index = currentCrossSection.getOuterPolygon().getPickedPointIndex(mouseX, mouseY,0);
			if(index != -1){
				//System.out.println(i + ", " + index);
				pickedCrossSectionIndex = i;
				pickedPointIndex = index;
				pickedPolygon = 1;	//i.e. outer
				return;
			}
			else{
				index = currentCrossSection.getInnerPolygon().getPickedPointIndex(mouseX, mouseY,0);
				if(index != -1){
					//System.out.println(i + ", " + index);
					pickedCrossSectionIndex = i;
					pickedPointIndex = index;
					pickedPolygon = 0;	//i.e. inner
					return;
				}
			}
			//System.out.println("---------\n" + currentCrossSection.getBasePolygon());
			//System.out.println(mouseX + ", " + mouseY);
			//System.out.println(currentCrossSection.getOuterPolygon());
			//System.out.println(currentCrossSection.getInnerPolygon());
		}
		pickedCrossSectionIndex = -1;
		pickedPointIndex = -1;
	}


	public void dragInXY() {
		if(pickedCrossSectionIndex == -1 || pickedPointIndex == -1)
			return;
		Polygon tempPoly, tempNextPoly, tempPrevPoly;
		if(pickedPolygon == 0){
			//inner
			tempPoly = crossSectionList.get(pickedCrossSectionIndex).getInnerPolygon();
			tempNextPoly = crossSectionList.get(pickedCrossSectionIndex+1).getInnerPolygon();
			tempPrevPoly = crossSectionList.get(pickedCrossSectionIndex+1).getInnerPolygon();
		}
		else{
			//outer
			tempPoly = crossSectionList.get(pickedCrossSectionIndex).getOuterPolygon();
			tempNextPoly = crossSectionList.get(pickedCrossSectionIndex+1).getOuterPolygon();
			tempPrevPoly = crossSectionList.get(pickedCrossSectionIndex+1).getOuterPolygon();
		}
		Vector translationAmount = new Vector(parent.mouseX - parent.pmouseX,parent.mouseY - parent.pmouseY,0);
		tempPoly.pointList.set(pickedPointIndex, tempPoly.pointList.get(pickedPointIndex).moveTo(translationAmount));
		int nextPickedPointIndex = (pickedPointIndex + 1)%crossSectionList.get(0).getBasePolygon().pointList.size();
		int previousPickedPointIndex = (pickedPointIndex + crossSectionList.get(0).getBasePolygon().pointList.size() - 1)%crossSectionList.get(0).getBasePolygon().pointList.size();
		int next2PickedPointIndex = (pickedPointIndex + 2)%crossSectionList.get(0).getBasePolygon().pointList.size();
		int previous2PickedPointIndex = (pickedPointIndex + crossSectionList.get(0).getBasePolygon().pointList.size() - 2)%crossSectionList.get(0).getBasePolygon().pointList.size();
		//Propagating in next cross section
		if(pickedCrossSectionIndex < crossSectionList.size()-1){
			tempNextPoly.pointList.set(pickedPointIndex, tempNextPoly.pointList.get(pickedPointIndex).moveTo(translationAmount.scaleBy(0.5f)));
			tempNextPoly.pointList.set(nextPickedPointIndex, tempPoly.pointList.get(nextPickedPointIndex).moveTo(translationAmount.scaleBy(0.25f)));
			tempNextPoly.pointList.set(previousPickedPointIndex, tempPoly.pointList.get(previousPickedPointIndex).moveTo(translationAmount.scaleBy(0.25f)));
		}
		//Propagating in previous crossSection
		if(pickedCrossSectionIndex > 0){
			tempPrevPoly.pointList.set(pickedPointIndex, tempPrevPoly.pointList.get(pickedPointIndex).moveTo(translationAmount.scaleBy(0.5f)));
			tempPrevPoly.pointList.set(nextPickedPointIndex, tempPoly.pointList.get(nextPickedPointIndex).moveTo(translationAmount.scaleBy(0.25f)));
			tempPrevPoly.pointList.set(previousPickedPointIndex, tempPoly.pointList.get(previousPickedPointIndex).moveTo(translationAmount.scaleBy(0.25f)));
		}
		//Propagating in pickedCrossSection
		tempPoly.pointList.set(nextPickedPointIndex, tempPoly.pointList.get(nextPickedPointIndex).moveTo(translationAmount.scaleBy(0.75f)));
		tempPoly.pointList.set(previousPickedPointIndex, tempPoly.pointList.get(previousPickedPointIndex).moveTo(translationAmount.scaleBy(0.75f)));
		if(crossSectionList.get(pickedCrossSectionIndex).getBasePolygon().pointList.size()>4){
			tempPoly.pointList.set(next2PickedPointIndex, tempPoly.pointList.get(next2PickedPointIndex).moveTo(translationAmount.scaleBy(0.5f)));
			tempPoly.pointList.set(previous2PickedPointIndex, tempPoly.pointList.get(previous2PickedPointIndex).moveTo(translationAmount.scaleBy(0.5f)));
		}
	}


	public void dragInZ() {
		if(pickedCrossSectionIndex == -1 || pickedPointIndex == -1)
			return;
		Polygon tempPoly, tempNextPoly, tempPrevPoly;
		if(pickedPolygon == 0){
			//inner
			tempPoly = crossSectionList.get(pickedCrossSectionIndex).getInnerPolygon();
			tempNextPoly = crossSectionList.get(pickedCrossSectionIndex+1).getInnerPolygon();
			tempPrevPoly = crossSectionList.get(pickedCrossSectionIndex+1).getInnerPolygon();
		}
		else{
			//outer
			tempPoly = crossSectionList.get(pickedCrossSectionIndex).getOuterPolygon();
			tempNextPoly = crossSectionList.get(pickedCrossSectionIndex+1).getOuterPolygon();
			tempPrevPoly = crossSectionList.get(pickedCrossSectionIndex+1).getOuterPolygon();
		}
		float movedBy = parent.pmouseY - parent.mouseY;
		Vector translationAmount = new Vector(0,0,movedBy);
		tempPoly.pointList.set(pickedPointIndex, tempPoly.pointList.get(pickedPointIndex).moveTo(translationAmount));
		int nextPickedPointIndex = (pickedPointIndex + 1)%crossSectionList.get(0).getBasePolygon().pointList.size();
		int previousPickedPointIndex = (pickedPointIndex + crossSectionList.get(0).getBasePolygon().pointList.size() - 1)%crossSectionList.get(0).getBasePolygon().pointList.size();
		int next2PickedPointIndex = (pickedPointIndex + 2)%crossSectionList.get(0).getBasePolygon().pointList.size();
		int previous2PickedPointIndex = (pickedPointIndex + crossSectionList.get(0).getBasePolygon().pointList.size() - 2)%crossSectionList.get(0).getBasePolygon().pointList.size();
		//Propagating in next cross section
		if(pickedCrossSectionIndex < crossSectionList.size()-1){
			tempNextPoly.pointList.set(pickedPointIndex, tempNextPoly.pointList.get(pickedPointIndex).moveTo(translationAmount.scaleBy(0.5f)));
			tempNextPoly.pointList.set(nextPickedPointIndex, tempPoly.pointList.get(nextPickedPointIndex).moveTo(translationAmount.scaleBy(0.25f)));
			tempNextPoly.pointList.set(previousPickedPointIndex, tempPoly.pointList.get(previousPickedPointIndex).moveTo(translationAmount.scaleBy(0.25f)));
		}
		//Propagating in previous crossSection
		if(pickedCrossSectionIndex > 0){
			tempPrevPoly.pointList.set(pickedPointIndex, tempPrevPoly.pointList.get(pickedPointIndex).moveTo(translationAmount.scaleBy(0.5f)));
			tempPrevPoly.pointList.set(nextPickedPointIndex, tempPoly.pointList.get(nextPickedPointIndex).moveTo(translationAmount.scaleBy(0.25f)));
			tempPrevPoly.pointList.set(previousPickedPointIndex, tempPoly.pointList.get(previousPickedPointIndex).moveTo(translationAmount.scaleBy(0.25f)));
		}
		//Propagating in pickedCrossSection
		tempPoly.pointList.set(nextPickedPointIndex, tempPoly.pointList.get(nextPickedPointIndex).moveTo(translationAmount.scaleBy(0.75f)));
		tempPoly.pointList.set(previousPickedPointIndex, tempPoly.pointList.get(previousPickedPointIndex).moveTo(translationAmount.scaleBy(0.75f)));
		if(crossSectionList.get(pickedCrossSectionIndex).getBasePolygon().pointList.size()>4){
			tempPoly.pointList.set(next2PickedPointIndex, tempPoly.pointList.get(next2PickedPointIndex).moveTo(translationAmount.scaleBy(0.5f)));
			tempPoly.pointList.set(previous2PickedPointIndex, tempPoly.pointList.get(previous2PickedPointIndex).moveTo(translationAmount.scaleBy(0.5f)));
		}
	}

}
