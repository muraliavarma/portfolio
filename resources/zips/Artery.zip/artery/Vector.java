package com.murlax.processing.artery;

public class Vector {
	
	private Point value;
	
	Vector(Point a, Point b){
		value = new Point();
		value.setX(b.getX()-a.getX());
		value.setY(b.getY()-a.getY());
		value.setZ(b.getZ()-a.getZ());
	}
	
	Vector(Point a){
		value = new Point();
		value.setX(a.getX());
		value.setY(a.getY());
		value.setZ(a.getZ());
	}
	
	Vector(Vector a){
		value = new Point();
		value.setX(a.getX());
		value.setY(a.getY());
		value.setZ(a.getZ());
	}
	
	Vector(float a, float b, float c){
		value = new Point(a,b,c);
	}
	
	public float getX(){
		return value.getX();
	}
	
	public float getY(){
		return value.getY();
	}
	
	public float getZ(){
		return value.getZ();
	}
	
	public void setX(float a){
		value.setX(a);
	}
	
	public void setY(float a){
		value.setY(a);
	}
	
	public void setZ(float a){
		value.setZ(a);
	}
	
	public float getLength(){
		return value.distanceTo(new Point(0,0,0));
	}
	
	public Vector toUnitVector(){
		Vector returnVector = new Vector(value);
		returnVector.setX(value.getX()/getLength());
		returnVector.setY(value.getY()/getLength());
		returnVector.setZ(value.getZ()/getLength());
		return returnVector;
	}
	
	public Vector scaleBy(float k){
		Vector returnVector = new Vector(value);
		returnVector.setX(value.getX()*k);
		returnVector.setY(value.getY()*k);
		returnVector.setZ(value.getZ()*k);
		return returnVector;
	}
	
	public Vector addTo(Vector a){
		Vector returnVector = new Vector(value);
		returnVector.setX(value.getX() + a.getX());
		returnVector.setY(value.getY() + a.getY());
		returnVector.setZ(value.getZ() + a.getZ());
		return returnVector;
	}
	
	//dot vector
	public float dot(Vector b){
		return getX()*b.getX() + getY()*b.getY() + getZ()*b.getZ();
	}
	
	
	//cross vector
	public Vector cross(Vector b){
		float a1 = getX();
		float a2 = getY();
		float a3 = getZ();
		
		float b1 = b.getX();
		float b2 = b.getY();
		float b3 = b.getZ();
		
		return new Vector(a2*b3 - a3*b2,a3*b1 - a1*b3, a1*b2 - a2*b1);
	}

	@Override
	public String toString() {
		return value.toString();
	}
	
	
}
