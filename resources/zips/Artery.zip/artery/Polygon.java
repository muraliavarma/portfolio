package com.murlax.processing.artery;

import java.util.ArrayList;

public class Polygon extends Shape {

	private boolean isClosed = false;
	private Point centerOfArea = new Point();
	private int numSmoothing = 0;
	private boolean isClockWise;
	
	public boolean isClockWise() {
		return isClockWise;
	}

	public Point getCenterOfArea() {
		return centerOfArea;
	}

	public void setClosed(boolean isClosed) {
		this.isClosed = isClosed;
	}

	//Might be useful later on for modifications, keeping it just in case. This stores the unsmoothened polygon
	private ArrayList<Point> originalPointList;

	public ArrayList<Point> getOriginalPointList() {
		return originalPointList;
	}

	public Polygon(MainArtery parent) {
		super(parent);
		pointList = new ArrayList<Point>();
		originalPointList = new ArrayList<Point>();
	}

	public void addPoint(Point point){
		addPoint(pointList.size(), point);
	}

	public void addPoint(int index, Point point){
		
		if(pointList.size() > 0 && point.distanceTo(pointList.get(0)) < Constants.POLYGON_CLOSE_DISTANCE_TOLERANCE){
			isClosed = true;
			parent.mode = Constants.POLYGON_SMOOTH_MODE;
			originalPointList = pointList;
			setCenterOfArea();
			if(Util.AUTO_SMOOTH_MODE)
				for(int i = 0; i < 3; i++)
					smoothen();
		}
		else{
			pointList.add(index, point);
		}
	}

	/**
	 * Smoothens the polygon created by following refine-dual-dual procedure
	 * 
	 */
	public void smoothen(){
		numSmoothing++;
		refine();
		dual();
		dual();
		setCenterOfArea();
	}

	private void refine(){
		ArrayList<Point> newPointList = new ArrayList<Point>();
		for (int i = 0; i < pointList.size(); i++) {
			newPointList.add(pointList.get(i));
			newPointList.add(Util.average(pointList.get(i), pointList.get((i+1)%pointList.size())));
		}
		pointList = newPointList;
	}

	private void dual(){
		for (int i = 0; i < pointList.size(); i++) {
			pointList.set(i, Util.average(pointList.get(i), pointList.get((i+1)%pointList.size())));
		}
	}

	/**
	 * Returns the center of area of a set of points after triangulating the polygon
	 * created by this set of points and calculating centroids for each triangle and
	 * averaging them based on their areas 
	 * @return Center of Area
	 */
	public void setCenterOfArea(){
		isClosed = true;
		ArrayList<Point> tempPointList = new ArrayList<Point>();
		for (int i = 0; i < pointList.size(); i++) {
			tempPointList.add(pointList.get(i));
		}

		float sumOfAngles = 0;
		Point sumOfCentroidAreas = new Point(0,0,0);
		float sumOfAreas = 0;

		while(tempPointList.size() > 2){

			for (int i = 0; i < tempPointList.size(); i++) {
				float theta = Util.turnAngle(tempPointList.get((i+tempPointList.size()-1)%tempPointList.size()), tempPointList.get(i), tempPointList.get((i+1)%tempPointList.size()));
				sumOfAngles += theta;
			}
			isClockWise = (sumOfAngles>0?true:false);

			for (int i = 0; i < tempPointList.size(); i++) {
				Point previousPoint = tempPointList.get((i+tempPointList.size()-1)%tempPointList.size());
				Point currentPoint = tempPointList.get(i);
				Point nextPoint = tempPointList.get((i+1)%tempPointList.size());
				float theta = Util.turnAngle(previousPoint, currentPoint, nextPoint);
				if(isClockWise && theta > 0 || !isClockWise && theta < 0){
					//System.out.println(i + " is pickable since angle is less than 180.");
					//now check if there is any other point in the triangle we are about to maul
					boolean fail = false;
					for (int j = 0; j < tempPointList.size(); j++) {
						if(j == i || j == (i+1)%tempPointList.size() || j == (i + tempPointList.size() - 1)%tempPointList.size())
							continue;
						if(Util.isPointInTriangle(tempPointList.get(j), previousPoint, currentPoint, nextPoint)){
							fail = true;
							break;
						}
					}
					if(!fail){
						//we can safely choose this triangle to be removed
						//System.out.println(i + " is the awesomeest point coz it is like awesome");
						float area = Util.areaOfTriangle(previousPoint, currentPoint, nextPoint);
						sumOfAreas += area;
						Point centroid = previousPoint.add(currentPoint).add(nextPoint).scaleBy(1.0f/3);
						sumOfCentroidAreas.setX(sumOfCentroidAreas.getX() + centroid.getX()*area);
						sumOfCentroidAreas.setY(sumOfCentroidAreas.getY() + centroid.getY()*area);
						sumOfCentroidAreas.setZ(sumOfCentroidAreas.getZ() + centroid.getZ()*area);
						//System.out.println("Centroid: " + centroid);
						//System.out.println("Area: " + area);
						tempPointList.remove(i);
					}
				}
			}
		}
		centerOfArea = sumOfCentroidAreas.scaleBy(1.0f/sumOfAreas);
		//System.out.println("Center of Area:" + centerOfArea);
//		float area = 0;
//		for (int i = 0; i < pointList.size() - 1; i++) {
//			area += pointList.get(i).getX()*pointList.get(i+1).getY() - pointList.get(i+1).getX()*pointList.get(i).getY();
//		}
//		area /= 2.0;
//
//		float cx=0, cy=0;
//		for (int i = 0; i < pointList.size() - 1; i++) {
//			cx += (pointList.get(i).getX() + pointList.get(i+1).getX())*(pointList.get(i).getX()*pointList.get(i+1).getY() - pointList.get(i+1).getX()*pointList.get(i).getY());
//			cy += (pointList.get(i).getY() + pointList.get(i+1).getY())*(pointList.get(i).getX()*pointList.get(i+1).getY() - pointList.get(i+1).getX()*pointList.get(i).getY());
//		}
//		cx /= 6.0*area;		
//		cy /= 6.0*area;
//		centerOfArea = new Point(cx,cy,0);
	}

	public void unSmoothen(){
		pointList = originalPointList;
		numSmoothing = 0;
	}

	public int getPickedPointIndex(int x, int y){
		for (int i = 0; i < pointList.size(); i++) {
			if(Math.abs(x - pointList.get(i).getX()) < Constants.POLYGON_PICK_DISTANCE_TOLERANCE
					&& Math.abs(y - pointList.get(i).getY()) < Constants.POLYGON_PICK_DISTANCE_TOLERANCE){
				//System.out.println(i);
				return i;
			}
		}
		return -1;
	}

	public int getPickedPointIndex(float x, float y, float z){
		for (int i = 0; i < pointList.size(); i++) {
			Point screenCoords = new Point(parent.screenX(pointList.get(i).getX(),pointList.get(i).getY(),pointList.get(i).getZ()),
					parent.screenY(pointList.get(i).getX(),pointList.get(i).getY(),pointList.get(i).getZ()),
					parent.screenZ(pointList.get(i).getX(),pointList.get(i).getY(),pointList.get(i).getZ()));
			Point pickedPoint = new Point(x,y,z);
			//System.out.println("Yo, screen here! - "  +screenCoords);
			if(new Vector(pickedPoint,screenCoords).getLength() < Constants.POLYGON_PICK_DISTANCE_TOLERANCE){
				return i;
			}
		}
		return -1;
	}

	public void draw() {
		//parent.stroke(100,0,0);
		
		for(int i=0;i<pointList.size();i++){
			Point currentPoint = pointList.get(i);
			if(parent.mode == Constants.POLYGON_DRAW_MODE || parent.mode == Constants.POLYGON_EDIT_MODE){
				parent.ellipse(currentPoint.getX(),currentPoint.getY(),5,5);
			}
			if(parent.mode == Constants.ARTERY_EDIT_MODE){
				//parent.picker.start(parent.pickCounter++);
				parent.pushMatrix();
				//parent.stroke(255);
				parent.translate(currentPoint.getX(),currentPoint.getY(),currentPoint.getZ());
				parent.sphereDetail(3);
				parent.sphere(Constants.SPHERE_RADIUS);
				parent.popMatrix();
			}
			if(i == pointList.size()-1 && !isClosed){
				//if the polygon is open, then don't draw the closing line
				break;
			}
			Point nextPoint = pointList.get((i+1)%pointList.size());
			if(parent.mode == Constants.POLYGON_DRAW_MODE || parent.mode == Constants.POLYGON_SMOOTH_MODE || parent.mode == Constants.POLYGON_EDIT_MODE)
				parent.stroke(255);
				parent.line(currentPoint.getX(),currentPoint.getY(),currentPoint.getZ(),nextPoint.getX(),nextPoint.getY(), nextPoint.getZ());
			
		}
		if(centerOfArea.getX() != -1 && (parent.mode == Constants.POLYGON_DRAW_MODE || parent.mode == Constants.POLYGON_EDIT_MODE))
			parent.ellipse(centerOfArea.getX(),centerOfArea.getY(),5,5);

	}

	@Override
	public String toString() {
		String returnString = "(";
		for (int i = 0; i < pointList.size(); i++) {
			returnString += pointList.get(i) + ", ";
		}
		return returnString+ ")";
	}

	
	
}
