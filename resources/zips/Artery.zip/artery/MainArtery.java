package com.murlax.processing.artery;


import java.awt.event.KeyEvent;

import processing.core.*;


public class MainArtery extends PApplet{

	private static final long serialVersionUID = 1L;
	private Polygon polygon;
	private CrossSection crossSection;
	private Artery artery;

	//mode defines whether we are in initial polygon drawing mode, artery mode etc
	public int mode;
	private int pickedPointIndex;
	private int previousMode;

	private float mouseXPos = 0;
	private float mouseYPos = 0;
	private boolean rotateFlag = false;
	private boolean moveFlag = false;
	private float movedPosX;
	private float movedPosY;
	private float previousMovedPosX = 0;
	private float previousMovedPosY = 0;
	private float startMovedPosX = 0;
	private float startMovedPosY = 0;
	private boolean scribeText = true;
	private boolean zFlag = false;
	
	public MainArtery() {
		polygon = new Polygon(this);
//		polygon.addPoint(new Point(100, 100, 0));
//		polygon.addPoint(new Point(100, 200, 0));
//		polygon.addPoint(new Point(200, 200, 0));
//		polygon.addPoint(new Point(200, 100, 0));
		mode = Constants.POLYGON_DRAW_MODE;
	}

	public void setup() {
		size(Constants.CANVAS_WIDTH,Constants.CANVAS_HEIGHT,P3D);
		stroke(0);
	}

	public void draw() {
		background(0);
		lights();
		//if(scribeText) 
			//displayText();
		pushMatrix();
		if(mode == Constants.POLYGON_DRAW_MODE ||
				mode == Constants.POLYGON_EDIT_MODE ||
				mode == Constants.POLYGON_SMOOTH_MODE){
			polygon.draw();
		}
		else if(mode == Constants.CROSS_SECTION_DRAW_MODE || mode == Constants.ARTERY_DRAW_MODE || mode == Constants.ARTERY_EDIT_MODE){
			//if(rotateFlag){
				float angle = atan2(mouseYPos,mouseXPos);
				float dist = (float) Math.sqrt(mouseXPos*mouseXPos + mouseYPos*mouseYPos);
				translate(Constants.CANVAS_WIDTH/2,Constants.CANVAS_WIDTH/2,0);
				rotateZ(angle);
				rotateY(dist*PI);
				rotateZ(-angle);
				translate(-Constants.CANVAS_WIDTH/2,-Constants.CANVAS_WIDTH/2,0);
			//}
			translate(movedPosX, movedPosY,0);
			if(artery != null){
				//translate and rotate such that latest cross section is nearest to screen
				
				//rotateY(-artery.getGlobalRotationY());
				//rotateX(-artery.getGlobalRotationX());

				Point centerOfAreaDiff = artery.getCrossSectionList().get(0).getBasePolygon().getCenterOfArea();
				centerOfAreaDiff = centerOfAreaDiff.add(artery.getCrossSectionList().get(artery.getCrossSectionList().size()-1).getBasePolygon().getCenterOfArea().scaleBy(-1));
				centerOfAreaDiff = centerOfAreaDiff.scaleBy(-1);
				//translate(centerOfAreaDiff.getX(),centerOfAreaDiff.getY(),0);
				//translate(0, 0,-artery.getGlobalTranslation());
			}
			crossSection.draw();
		}
		if(mode == Constants.ARTERY_DRAW_MODE || mode == Constants.ARTERY_EDIT_MODE){
			artery.draw();
		}
		popMatrix();
	}


	public void mouseClicked(){
		if(mode == Constants.POLYGON_DRAW_MODE)
			polygon.addPoint(new Point(mouseX,mouseY,0));
		if(mode == Constants.ARTERY_DRAW_MODE)
			artery.addCrossSection(new Point(mouseX,mouseY,0));
	}
	
	public void mousePressed(){
		if(mode == Constants.POLYGON_EDIT_MODE){
			pickedPointIndex = polygon.getPickedPointIndex(mouseX, mouseY);
		}
		if(mode == Constants.ARTERY_EDIT_MODE){
			artery.pickClosestPoint(mouseX, mouseY,0);
		}
		startMovedPosX = (float) (mouseX - Constants.CANVAS_WIDTH/2.0);
		startMovedPosY = (float) (mouseY - Constants.CANVAS_HEIGHT/2.0);
	}

	public void mouseDragged() {
		super.mouseDragged();
		if(moveFlag){
			movedPosX = (float) (previousMovedPosX + mouseX - startMovedPosX - Constants.CANVAS_WIDTH/2.0);
			movedPosY = (float) (previousMovedPosY + mouseY - startMovedPosY - Constants.CANVAS_HEIGHT/2.0);
		}
		if(rotateFlag){
			mouseXPos = (float) ((mouseX-Constants.CANVAS_WIDTH/2.0)/Constants.CANVAS_WIDTH);
			mouseYPos = (float) ((mouseY-Constants.CANVAS_HEIGHT/2.0)/Constants.CANVAS_HEIGHT);
		}
		if(mode == Constants.POLYGON_EDIT_MODE && pickedPointIndex != -1){
			polygon.pointList.remove(pickedPointIndex);
			polygon.addPoint(pickedPointIndex, new Point(mouseX,mouseY,0));
			polygon.setCenterOfArea();
		}
		if(mode == Constants.ARTERY_EDIT_MODE){
			if(zFlag)
				artery.dragInZ();
			else
				artery.dragInXY();
		}
	}
	
	public void mouseReleased(){
		super.mouseReleased();
	}

	@Override
	public void keyPressed(KeyEvent e) {
		super.keyPressed(e);
		if(e.getKeyChar() == 'q'){	//reset rotation and translation
			movedPosX = 0; movedPosY = 0;
			mouseXPos = 0; mouseYPos = 0;
		}
		if(e.getKeyChar() == 'h'){
			scribeText = !scribeText;
		}
		if(e.getKeyChar() == 'x'){
			Util.AUTO_SMOOTH_MODE = !Util.AUTO_SMOOTH_MODE;
		}
		if(mode == Constants.POLYGON_SMOOTH_MODE){
			if(e.getKeyChar() == 's'){
				//smoothen the polygon
				polygon.smoothen();
			}
			if(e.getKeyChar() == 'c'){
				//change to cross section mode
				crossSection = new CrossSection(this,polygon);
				mode = Constants.CROSS_SECTION_DRAW_MODE;
				//rotateX(PI/3);
			}
		}
		if(mode == Constants.CROSS_SECTION_DRAW_MODE || mode == Constants.ARTERY_DRAW_MODE || mode == Constants.ARTERY_EDIT_MODE){
			//note that this is not an else if, so once d is pressed, it will jump here
			if(e.getKeyChar() == 'p'){
				//change to original polygon smoothing mode
				//if you wanna go back to edit the poly, click e after this
				mode = Constants.POLYGON_SMOOTH_MODE;
			}
			if(e.getKeyChar() == 'r')
				rotateFlag = true;
			if(e.getKeyChar() == 't')
				moveFlag = true;
			if(e.getKeyChar() == 'a'){
				artery = new Artery(this,crossSection);
				mode = Constants.ARTERY_DRAW_MODE;
			}
		}
		if(e.getKeyChar() == 'e'){
			if(mode == Constants.POLYGON_EDIT_MODE || mode == Constants.ARTERY_EDIT_MODE){
				mode = previousMode;
			}
			else if(mode == Constants.POLYGON_SMOOTH_MODE){
				previousMode = mode;
				mode = Constants.POLYGON_EDIT_MODE;
			}
			else if(mode == Constants.ARTERY_DRAW_MODE){
				previousMode = mode;
				mode = Constants.ARTERY_EDIT_MODE;
			}
		}
		if(mode == Constants.POLYGON_SMOOTH_MODE && e.getKeyChar() == 'u'){
			polygon.unSmoothen();
		}

		if(mode == Constants.ARTERY_DRAW_MODE && e.getKeyChar() == 'u'){
			artery.unSmoothen();
		}

		if(mode == Constants.ARTERY_DRAW_MODE && e.getKeyChar() == 's'){
			artery.smoothen();
		}
		
		if(mode == Constants.ARTERY_EDIT_MODE && e.getKeyChar() == 'z'){
			zFlag = true;
		}
	}

	
	@Override
	public void keyReleased() {
		super.keyReleased();
		if(key == 'r'){
			rotateFlag = false;
		}
		if(key == 't'){
			moveFlag = false;
			previousMovedPosX = movedPosX;
			previousMovedPosY = movedPosY;
		}
		if(key == 'z' && mode == Constants.ARTERY_EDIT_MODE)
			zFlag = false;
	}
	
	public void displayText(){
			scribeHeader("Computer Graphics Project 2");
			scribeFooter("r: rotate, t: translate q: reset transformations",0);
			scribeFooter("c: cross-section mode, a: artery mode",2);
			scribeFooter("e: edit polygon/artery, s: smoothen polygon/artery u: un-smoothen polygon/artery",1);
	}
	
	public void scribeHeader(String S) {
		PFont font;
		PFont.list();
		font =  loadFont("Calibri-15.vlw");
		//font = createFont("FFScala",14);
		textFont(font);
	
		fill(255);
		text(S,10,20); 
		fill(255);
	} // writes on screen at line i
	
	public void scribeHeaderRight(String S) {fill(255); text(S,width-S.length()*9,20); noFill();} // writes on screen at line i
	
	public void scribeFooter(String S, int i) {fill(255); text(S,10,height-10-i*20); noFill();} // writes on screen at line i

	
	public static void main(String args[]) {
		PApplet.main(new String[] { "--present", "com.murlax.processing.MainArtery" });
	}
}
