package com.murlax.processing.artery;

public class Util {
	public static boolean AUTO_SMOOTH_MODE = true;
	
	static public Point average(Point a, Point b) {
		// (A+B)/2 (average)
		return new Point((a.getX()+b.getX())/2,(a.getY()+b.getY())/2,(a.getZ()+b.getZ())/2); 
	}                                          
	
	static public Point average(Point a, Point b, Point c) {
		// (A+B+C)/3 (average)
		return new Point((a.getX() +b.getX()+c.getX())/3,(a.getY()+b.getY()+c.getY())/3,(a.getZ()+b.getZ()+c.getZ())/3); 
	}                            


	static public Vector angleBisector(Vector a, Vector b){
		a = a.toUnitVector();
		b = b.toUnitVector();
		Vector returnVector = a.addTo(b);
		return returnVector.toUnitVector();
	}
	
	static public Point getPointOfIntersection(Vector v1, Point p1, Vector v2, Point p2){
		//v1 passes through p1, v2 passes through p2
		//l1 = p1 + a*v1
		//l2 = p2 + b*v2
		//solving the above 2, we get a = |(p2-p1) x v2|/|v1 x v2|
		//point of intersection is then p1 + a*v1
		
		Vector tempVector1 = (new Vector(p1, p2).cross(v2));
		Vector tempVector2 = v1.cross(v2);
		float a = tempVector1.getLength();
		a /= tempVector2.getLength();
		if(tempVector1.getX() * tempVector2.getX() < 0)
			a *= -1;
		return p1.moveTo(v1.scaleBy(a));
	}
	
	static public float turnAngle(Point a, Point b, Point c){
		return angle(new Vector(a,b),new Vector(b,c));
	}

	static public float angle(Vector a, Vector b) {
		return (float) Math.atan2(rotate(a).dot(b), a.dot(b));
	}

	static public Vector rotate(Vector a) {
		Vector returnVector = new Vector(a);
		returnVector.setY(a.getX());
		returnVector.setX(a.getY()*-1);
		return returnVector;
	}
	
	static public boolean isSameSide(Point p1, Point p2, Point a, Point b){
		Vector crossProduct1 = new Vector(a,b).cross(new Vector(a,p1));
		Vector crossProduct2 = new Vector(a,b).cross(new Vector(a,p2));
		if(crossProduct1.dot(crossProduct2) >= 0)
			return true;
		return false;
	}
	
	static public boolean isPointInTriangle(Point p, Point a, Point b, Point c){
		if(isSameSide(p, a, b, c) && isSameSide(p, b, a, c) && isSameSide(p, c, a, b))
			return true;
		return false;
	}
	
	static public float areaOfTriangle(Point a, Point b, Point c){
		Vector v1 = new Vector(a,b);
		Vector v2 = new Vector(a,c);
		return v1.cross(v2).getLength()/2;
	}
	
}
