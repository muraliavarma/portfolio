package com.murlax.processing.artery;

public class Constants {
	public static final int CANVAS_WIDTH = 1000;
	public static final int CANVAS_HEIGHT = 800;
	
	public static final int POLYGON_DRAW_MODE = 0;
	public static final int POLYGON_SMOOTH_MODE = 1;
	public static final int CROSS_SECTION_DRAW_MODE = 2;
	public static final int ARTERY_DRAW_MODE = 3;
	public static final int POLYGON_EDIT_MODE = 4;
	public static final int ARTERY_EDIT_MODE = 5;
	
	public static final float POLYGON_CLOSE_DISTANCE_TOLERANCE = 5.0f;
	public static final float POLYGON_PICK_DISTANCE_TOLERANCE = 5.0f;
	public static final float CROSS_SECTION_OFFSET_DISTANCE = 13.0f;
	public static final float ARTERY_OFFSET_DISTANCE = 5.0f;
	public static final float LENGTH_ANGLE_COREL = CANVAS_WIDTH;
	public static final float MAX_ROTATE_ANGLE = (float) (Math.PI/2);
	public static final float SPHERE_RADIUS = 1.5f;
}
