package com.murlax.processing.artery;

import java.util.ArrayList;

public abstract class Shape{
	protected MainArtery parent;
	protected ArrayList<Point> pointList;
	
	Shape(MainArtery p){
		parent = p;
	}

	public abstract void draw();
}
