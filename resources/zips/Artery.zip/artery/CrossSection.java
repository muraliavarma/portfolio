package com.murlax.processing.artery;

public class CrossSection extends Shape {

	private Polygon basePolygon;

	//use basePolygon, centerOfArea and offset (defined in Constants) to define outerPolygon and innerPolygon
	private Polygon outerPolygon;
	
	public Polygon getOuterPolygon() {
		return outerPolygon;
	}

	public void setOuterPolygon(Polygon outerPolygon) {
		this.outerPolygon = outerPolygon;
	}

	public Polygon getInnerPolygon() {
		return innerPolygon;
	}

	public void setInnerPolygon(Polygon innerPolygon) {
		this.innerPolygon = innerPolygon;
	}

	private Polygon innerPolygon;

	CrossSection(MainArtery p, Polygon basePolygon) {
		super(p);
		this.basePolygon = basePolygon;
		this.basePolygon.pointList = basePolygon.pointList;
		calculateOffsetPolygons();
	}
	
	CrossSection(MainArtery p, Polygon basePolygon, Polygon innerPolygon, Polygon outerPolygon) {
		super(p);
		this.basePolygon = basePolygon;
		this.innerPolygon = innerPolygon;
		this.outerPolygon = outerPolygon;
		this.basePolygon.pointList = basePolygon.pointList;
		this.outerPolygon.pointList = outerPolygon.pointList;
		this.innerPolygon.pointList = innerPolygon.pointList;
	}
	
	public Polygon getBasePolygon() {
		return basePolygon;
	}
	
	public void setBasePolygon(Polygon basePolygon) {
		this.basePolygon = basePolygon;
	}

	public void drawMesh(){
		for (int i = 0; i <  basePolygon.pointList.size(); i++) {
			Point currentOuterPoint = outerPolygon.pointList.get(i);
			Point currentInnerPoint = innerPolygon.pointList.get(i);
			Point nextOuterPoint = outerPolygon.pointList.get((i+1)%basePolygon.pointList.size());
			Point nextInnerPoint = innerPolygon.pointList.get((i+1)%basePolygon.pointList.size());
			parent.fill(150,150,150);
			parent.noStroke();
			parent.beginShape();
			parent.vertex(currentOuterPoint.getX(), currentOuterPoint.getY(), currentOuterPoint.getZ());
			parent.vertex(nextOuterPoint.getX(), nextOuterPoint.getY(), nextOuterPoint.getZ());
			parent.vertex(nextInnerPoint.getX(), nextInnerPoint.getY(), nextInnerPoint.getZ());
			parent.vertex(currentInnerPoint.getX(), currentInnerPoint.getY(), currentInnerPoint.getZ());
			parent.endShape();
		}
}

	
	private void calculateOffsetPolygons(){
		outerPolygon = new Polygon(parent);
		innerPolygon = new Polygon(parent);
		innerPolygon.setClosed(true);
		outerPolygon.setClosed(true);
		int polygonSize = basePolygon.pointList.size();
		for (int i = 0; i < polygonSize; i++) {
			Vector vectorToPrevious = new Vector(basePolygon.pointList.get(i),basePolygon.pointList.get((i+polygonSize-1)%polygonSize));
			Vector vectorToNext = new Vector(basePolygon.pointList.get(i),basePolygon.pointList.get((i+1)%polygonSize));
			Vector vectorToCenter = Util.angleBisector(vectorToPrevious, vectorToNext);
			//If the angle is convex, we need to swap inner and outer points
//			float angle1 = MainArtery.atan2(vectorToNext.getX(), vectorToNext.getY());
//			float angle2 = MainArtery.atan2(vectorToPrevious.getX(), vectorToPrevious.getY());
//			if(angle1 < 0)
//				angle1 += 2*MainArtery.PI;
//			if(angle2 < 0)
//				angle2 += 2*MainArtery.PI;
//			if(angle1 - angle2 > 0){
//				vectorToCenter = vectorToCenter.scaleBy(-1);
//			}
//			System.out.println(i + ", " + vectorToNext.toString() + ", " + vectorToPrevious.toString() + ", " + vectorToCenter.toString());
//			float sinTheta = vectorToNext.cross(vectorToPrevious).getLength()/(vectorToNext.getLength()*vectorToPrevious.getLength());
//			double thetaByTwo = Math.asin(sinTheta)/2.0;
//			double offset = Constants.CROSS_SECTION_OFFSET_DISTANCE/Math.sin(thetaByTwo);
			//int direction = 1;
			
			
			//if(vectorToNext.cross(vectorToPrevious).getZ() < 0){
				//vectorToCenter = vectorToCenter.scaleBy(-1);
			//	direction = -1;
			//}
			
//			Vector perpendicularNextVector = vectorToNext.cross(new Vector(0,0,-direction)).toUnitVector();
//			Vector perpendicularPreviousVector = vectorToPrevious.cross(new Vector(0,0,direction)).toUnitVector();
//			Point outerNextMidPoint = Util.average(basePolygon.pointList.get(i), basePolygon.pointList.get((i+1)%polygonSize));
//			outerNextMidPoint = outerNextMidPoint.moveTo(perpendicularNextVector.scaleBy(Constants.CROSS_SECTION_OFFSET_DISTANCE));
//			Point outerPreviousMidPoint = Util.average(basePolygon.pointList.get(i), basePolygon.pointList.get((i+polygonSize-1)%polygonSize));
//			outerPreviousMidPoint = outerPreviousMidPoint.moveTo(perpendicularPreviousVector.scaleBy(Constants.CROSS_SECTION_OFFSET_DISTANCE));
//			outerPolygon.pointList.add(outerNextMidPoint);
//			outerPolygon.pointList.add(Util.getPointOfIntersection(vectorToNext, outerNextMidPoint, vectorToPrevious, outerPreviousMidPoint));

			vectorToCenter = vectorToCenter.scaleBy(Constants.CROSS_SECTION_OFFSET_DISTANCE);
			basePolygon.setCenterOfArea();
			if(basePolygon.isClockWise() && vectorToNext.cross(vectorToPrevious).getZ() < 0 ||
					!basePolygon.isClockWise() && vectorToNext.cross(vectorToPrevious).getZ() >= 0)
				outerPolygon.pointList.add(basePolygon.pointList.get(i).moveTo(vectorToCenter));
			else
				innerPolygon.pointList.add(basePolygon.pointList.get(i).moveTo(vectorToCenter));
			
			vectorToCenter = vectorToCenter.scaleBy(-1);
			
			if(basePolygon.isClockWise() && vectorToNext.cross(vectorToPrevious).getZ() < 0 ||
					!basePolygon.isClockWise() && vectorToNext.cross(vectorToPrevious).getZ() >= 0)
				innerPolygon.pointList.add(basePolygon.pointList.get(i).moveTo(vectorToCenter));
			else
				outerPolygon.pointList.add(basePolygon.pointList.get(i).moveTo(vectorToCenter));
		}
		
	}

	@Override
	public void draw() {
		if(parent.mode == Constants.ARTERY_DRAW_MODE || parent.mode == Constants.ARTERY_EDIT_MODE){
			parent.pushMatrix();
			parent.stroke(255);
			parent.translate(basePolygon.getCenterOfArea().getX(),basePolygon.getCenterOfArea().getY(),basePolygon.getCenterOfArea().getZ());
			parent.sphereDetail(3);
			parent.sphere(Constants.SPHERE_RADIUS);
			parent.popMatrix();
			parent.noStroke();
			outerPolygon.draw();
			innerPolygon.draw();
		}
		else{
			parent.stroke(255,0,0);
			//calculateOffsetPolygons();
			outerPolygon.draw();
			parent.stroke(0,0,255);
			innerPolygon.draw();
			//parent.stroke(255);
			//basePolygon.draw();
		}
		
	}

}
