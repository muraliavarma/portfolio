package com.murlax.processing.artery;

public class Point {
	private float x;
	private float y;
	private float z;
	
	Point () {
		this.x = -1;
		this.y = -1;
		this.z = -1; 
	}
	
	Point (float x, float y, float z){
		this.x = x;
		this.y = y;
		this.z = z;
	}
	
	Point (Point P) {
		this.x = P.getX();
		this.y = P.getY();
		this.z = P.getZ(); 
	}
	
	public float getX() {
		return x;
	}
	public void setX(float x) {
		this.x = x;
	}
	public float getY() {
		return y;
	}
	public void setY(float y) {
		this.y = y;
	}
	public float getZ() {
		return z;
	}
	public void setZ(float z) {
		this.z = z;
	}
	
	public void setPoint(Point P){
		this.setX(P.getX());
		this.setY(P.getY());
		this.setZ(P.getZ());
	}
	
	public void setPoint(float x, float y, float z){
		this.setX(x);
		this.setY(y);
		this.setZ(z);
	}
	
	public float distanceTo(Point otherPoint){
		float diffX = Math.abs(otherPoint.getX()-x);
		float diffY = Math.abs(otherPoint.getY()-y);
		float diffZ = Math.abs(otherPoint.getZ()-z);
		return (float) Math.sqrt(diffX*diffX + diffY*diffY + diffZ*diffZ);
	}
	
	public Point moveTo(Vector vector){
		Point returnPoint = new Point(this);
		returnPoint.x += vector.getX();
		returnPoint.y += vector.getY();
		returnPoint.z += vector.getZ();
		return returnPoint;
	}
	
	public Point add(Point point){
		return moveTo(new Vector(point));
	}
	
	public Point scaleBy(float k){
		Point returnPoint = new Point(this);
		returnPoint.x *=k;
		returnPoint.y *=k;
		returnPoint.z *=k;
		return returnPoint;
	}
	
	@Override
	public String toString() {
		return "(" + this.x + ", " + this.y + ", " + this.z + ")";
	}	
}
