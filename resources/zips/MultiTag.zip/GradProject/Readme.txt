Unzip and open as unity project.

To try out the editor, create a new scene. Add an empty game object and attach the MultitTagManager script to it. That is the only set up required. If the files didn't get copied correctly, place the two files ending with editor inside an editor folder in the project. Place the other non-editor scripts anywhere in the project.

Add multiple tags to any game object from the drop down in transform functions. (The original single tag is kept there as it is, untouched). View these tags by clicking the empty game object that has the MultiTagManager script attached to it.

Perform basic operations on the tags by running attaching SampleScript to another empty game object. This demos the basic APIs exposed by the manager script (these are static functions at the bottom of the manager file).