#pragma strict

var selectedTags = 0;

function Start () {

}

function Update () {

}

function GetMultiTagNames(){
	var retArray:Array = new Array();
	for(var i=0;i<UnityEditorInternal.InternalEditorUtility.tags.Length;i++){
		if(((1<<i) & selectedTags) != 0){
			retArray.Push(UnityEditorInternal.InternalEditorUtility.tags[i]);
		}
	}
	return retArray.ToBuiltin(String);
}