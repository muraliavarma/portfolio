#pragma strict

function Start () {

}

function Update () {
	//Examples

	//Get Tag Name of Game Object
	var tags : String[] = MultiTagManager.GetTagIds(this.gameObject);
	for(var tag in tags){
		Debug.Log("Tag: " + tag);
	}

	//Get Game Objects of particular tag
	var gos : GameObject[] = MultiTagManager.GetGameObjectsWithTag("Player");
	for(var go in gos){
		Debug.Log("Game Object: " + go.name);
	}

	//Get Game Objects which have at least one the tags being passed
	gos = MultiTagManager.GetGameObjectsWithTagsDisjunction(["Respawn","Finish","Player"]);
	for(var go in gos){
		Debug.Log("Disj: Game Object: " + go.name);
	}

		//Get Game Objects which have all the tags being passed
	gos = MultiTagManager.GetGameObjectsWithTagsConjunction(["Respawn","Finish","Player"]);
	for(var go in gos){
		Debug.Log("Conj: Game Object: " + go.name);
	}
}