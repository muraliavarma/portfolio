@CustomEditor (MultiTagManager)
class MultiTagManagerEditor extends Editor {
	
    function OnInspectorGUI () {
    	EditorGUILayout.BeginVertical("Box");
    	
    	EditorGUILayout.BeginHorizontal("Label");
    	EditorGUILayout.LabelField("Tag",EditorStyles.boldLabel);
    	EditorGUILayout.LabelField("Game Object",EditorStyles.boldLabel);
    	EditorGUILayout.EndHorizontal();
    	EditorGUILayout.Separator();
    	if(target == null || target.tags == null)
    		return;
		for(var i = 0; i< target.tags.length; i++){
	    	HorizontalLine();
			var tags : ArrayList = target.tags[i];
	    	EditorGUILayout.BeginHorizontal("Label");
			EditorGUILayout.LabelField(UnityEditorInternal.InternalEditorUtility.tags[i],EditorStyles.boldLabel);
			EditorGUILayout.BeginVertical("Label");
			if(tags.Count == 0){
				EditorGUILayout.LabelField("-No game objects with this tag-");
			}
			else{
				for(var go:GameObject in tags){
					if(GUILayout.Button(go.name)){
						EditorGUIUtility.PingObject(go);
						go.GetComponent(MultiTagScript).GetMultiTagNames();
					}
				}
			}
			EditorGUILayout.EndVertical();
	    	EditorGUILayout.EndHorizontal();
		}
		EditorGUILayout.EndVertical();
		
		
		//DrawDefaultInspector();
	}
	
	function HorizontalLine() {
	    var splitter = new GUIStyle("Box");
	    splitter.border = new RectOffset(1, 1, 1, 1);
	    splitter.stretchWidth = true;
	    splitter.margin = new RectOffset(0, 0, 7, 7);
	    GUILayout.Box("", splitter, GUILayout.Height(1.0f));
	}
}