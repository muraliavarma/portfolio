@CustomEditor (typeof(Transform))
class GameObjectMultiTagEditor extends Editor {

	var selectedTags = 0;
	var oldSelectedTags = 0;

    function OnInspectorGUI () {		
    	if(target.gameObject.GetComponent(MultiTagScript) == null){
    		target.gameObject.AddComponent(MultiTagScript);
    	}
   		target.gameObject.GetComponent(MultiTagScript).hideFlags = HideFlags.HideInInspector;
        selectedTags = target.gameObject.GetComponent(MultiTagScript).selectedTags;
        oldSelectedTags = selectedTags;
		EditorGUILayout.Space();
        selectedTags = EditorGUILayout.MaskField("Multi Tags", selectedTags, UnityEditorInternal.InternalEditorUtility.tags);
		target.transform.position = EditorGUILayout.Vector3Field("Position",target.transform.position);
		target.transform.eulerAngles = EditorGUILayout.Vector3Field("Rotation",target.transform.eulerAngles);
		target.transform.localScale = EditorGUILayout.Vector3Field("Scale",target.transform.localScale);
		EditorGUILayout.Space();
		if(target.transform.GetChildCount() == 0){
			target.gameObject.GetComponent(MultiTagScript).selectedTags = selectedTags;
		}
		else{
			//ask if children needs to be tagged too 
			if(oldSelectedTags != selectedTags){ 
				var option = EditorUtility.DisplayDialogComplex(
		                "Apply multitags for all child objects?",
		                "Please choose one of the following options.",
		                "Yes, change children",
		                "No, this object only",
		                "Cancel");
		        switch (option) {
		            // Apply children
		            case 0:
		                var childScripts = target.transform.GetComponentsInChildren(MultiTagScript);
		                for(var childScript in childScripts){
		                	childScript.selectedTags = selectedTags;
		                }
	               		target.gameObject.GetComponent(MultiTagScript).selectedTags = selectedTags;
		                break;
		            // Only me
		            case 1:
						target.gameObject.GetComponent(MultiTagScript).selectedTags = selectedTags;
		                break;
		            case 2:
		            	break;
		            default:
		                Debug.LogError("Unrecognized option.");
		
		        }
		    }
	    }
        //check for prefabs
        //if(PrefabUtility.GetPrefabParent(target) == null)
        //	Debug.Log("Not a prefab");
        //else{
        	//Debug.Log("{{{{  " + GetPath(PrefabUtility.GetPrefabParent(target)));
        	//EditorPrefs.SetInt(GetPath(PrefabUtility.GetPrefabParent(target)),selectedTags);
        //	var props = PrefabUtility.GetPropertyModifications(target);
        //	for(var prop:PropertyModification in props)
        //		Debug.Log(prop.value + ", " + prop.propertyPath);
        //}
                    
		//DrawDefaultInspector();

    }    
}