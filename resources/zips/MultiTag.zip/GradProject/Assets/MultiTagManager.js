#pragma strict
@script ExecuteInEditMode()
static var tags : Array;
function Start () {

}

function Update () {
	tags = Array(UnityEditorInternal.InternalEditorUtility.tags.Length);
	for(var j=0;j<UnityEditorInternal.InternalEditorUtility.tags.Length;j++){
		tags[j] = new ArrayList();
	}
	for(var go:GameObject in GameObject.FindObjectsOfType(GameObject)){
		var value = go.GetComponent(MultiTagScript).selectedTags;
		for(var i=0;i<UnityEditorInternal.InternalEditorUtility.tags.Length;i++){
			if(((1<<i) & value) != 0){
				(tags[i] as ArrayList).Add(go);
			}
		}
	}
}

static function GetTagIds(go:GameObject){
	return go.GetComponent(MultiTagScript).GetMultiTagNames();
}

static function GetGameObjectsWithTag(tagName:String){
	var tagId : int = -1;
	var retArray:Array = new Array();

	for(var i=0;i<UnityEditorInternal.InternalEditorUtility.tags.Length;i++){
		if(UnityEditorInternal.InternalEditorUtility.tags[i] == tagName){
			tagId = i;
			break;
		}
	}
	for(var tagItem in tags[tagId]){
		retArray.Push(tagItem);
	}
	return retArray.ToBuiltin(GameObject);
}

//AND operator
static function GetGameObjectsWithTagsConjunction(tagNames:String[]){
	var retArray : Array = new Array();
	for(var go:GameObject in GameObject.FindObjectsOfType(GameObject)){
		var goTagNames:String[] = GetTagIds(go);
		var containsOuter = true;
		for(var tagName in tagNames){
			var contains = false;
			for(var goTagName in goTagNames){
				if(tagName == goTagName){
					contains = true;
					break;
				}
			}
			if(!contains){
				//then this game object doesn't have one of the tags
				containsOuter = false;
				break;
			}
		}
		if(containsOuter)
			retArray.push(go);
	}
	return retArray.ToBuiltin(GameObject);
}

//OR operator
static function GetGameObjectsWithTagsDisjunction(tagNames:String[]){
	var retArray : Array = new Array();
	for(var tagName in tagNames){
		var gos = GetGameObjectsWithTag(tagName);
		for(var go in gos){
			var contains = false;
			for(var ret in retArray){
				if(go == ret){
					contains = true;
					break;
				}
			}
			if(!contains){
				retArray.push(go);
			}
		}
	}
	return retArray.ToBuiltin(GameObject);
}